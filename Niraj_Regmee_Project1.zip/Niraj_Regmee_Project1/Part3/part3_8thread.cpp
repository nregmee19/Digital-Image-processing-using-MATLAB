#include <omp.h>
#include <iostream>
#include <ctime>
using namespace std;
int main()
{
	int count = 0, i;
	int const size = 100000;
	int myArray[size];
	omp_set_num_threads(8);

	double start_time, end_time;
	//initialize random number generator
	srand((unsigned)time(NULL));
	// Initialize the array using random numbers
#pragma omp parallel
	for (i = 0; i < size; i++)
		myArray[i] = rand() % 100;
	//Serial Code
	start_time = omp_get_wtime();
#pragma omp parallel
	for (i = 0; i < size; i++)
		if (myArray[i] == 99)
			count++;
	end_time = omp_get_wtime();
	printf("The serial code indicates that there are %d 99s in the array.\n\n", count);
	printf("The serial code used %f seconds to complete the execution.\n\n", end_time - start_time);
	return 0;
}