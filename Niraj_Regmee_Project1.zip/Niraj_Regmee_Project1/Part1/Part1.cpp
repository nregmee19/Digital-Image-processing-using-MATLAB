#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *FibonacciThread(void *arg);
void createCreateAndRunThread(int nthreads);
int Fibbo(int n);


struct thread_info {
	pthread_t thread_sys_id;
	int thread_prog_id;
	int fibNum;
};

int* arrResult = (int *)malloc(45 * sizeof(int));

/*Main Threads*/
int main(int arg, char *args[]) {
	int nThreads = atoi(args[1]);
	createCreateAndRunThread(nThreads);
	printf("\n\nNo Of threads entered  : %d\n\n", nThreads);
	return 0;
}

/*Fibonacci Threads*/
void *FibonacciThread(void *arg) {
	int runningThreadProgId;
	runningThreadProgId = *(int *)arg;
	arrResult[runningThreadProgId] = Fibbo(runningThreadProgId);
	return NULL;
}



/*Creating requirest number of threads*/
void createCreateAndRunThread(int nthreads) {
	int i;
	struct thread_info* threadInfo;
	threadInfo = (struct thread_info*)malloc(nthreads * sizeof(struct thread_info));

	for (i = 0; i<nthreads; i++) {
		threadInfo[i].thread_prog_id = i;
		if (pthread_create(&threadInfo[i].thread_sys_id, NULL, FibonacciThread, &threadInfo[i].thread_prog_id)) {
			fprintf(stderr, "Error joining thread %d\n", threadInfo[i].thread_prog_id);
			return;
		}
	}
	for (i = 0; i<nthreads; i++) {
		if (pthread_join(threadInfo[i].thread_sys_id, NULL)) {
			fprintf(stderr, "Error joining thread %d\n", threadInfo[i].thread_prog_id);
			return;
		}
	}
	printf(" %d threads joined sucessfully\n", nthreads);
	for (int i = 0; i< nthreads; i++) {
		printf("Fibonacci[%d] is %d\n ", i, arrResult[i]);
	}
}


/*Fibonacchi calculation*/
int Fibbo(int n) {
	if (n == 0) {
		return 0;
	}
	if (n == 1 || n == 2) {
		return 1;
	}
	int result;
	for (int i = 2; i <= n; i++) {
		result = Fibbo(i - 1) + Fibbo(i - 2);
	}
	return result;
}
