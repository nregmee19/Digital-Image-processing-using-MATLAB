// Project2.cpp : Defines the entry point for the console application.
//

#include <unistd.h>
#include <sys/types.h>  
#include <errno.h>      
#include <stdio.h>      
#include <stdlib.h>     
#include <string.h>     
#include <semaphore.h>
#include <fstream>
#include <sys/wait.h>

/*
//In this part, you will use Pthreads, mutex locks, semaphores or conditional variables(optional) to solve the sleeping teaching assistant
	//problem.
//Assume that your instructor hires a teaching assistant(TA) who helps students with their programming assignments during regular office hours.
//The TA�s office is rather small and has room for only one desk with a chair and computer.
//There are three chairs in the hallway outside the office where students can sit and wait if the TA is currently helping another student.
//When there are no students who need help during office hours, the TA sits at the desk and takes a nap.
//If a student arrives during office hours and finds the TA sleeping, the student must awaken the TA to ask for help.
//If a student arrives and finds the TA currently helping another student, the student sits on one of the chairs in the hallway and waits.
//If no chairs are available, the student will come back at a later time.
*/
int Chair[3];
int availableStudent;
int head, tail, count;
bool tabusy, stdAvl, taSleeping, fstStd;
sem_t full, empty, mutAvlStd, mutex;

int stop = 0;




bool findInQueue(int num);
void insert(int num);
int remove();

void iniver();
void* student(void* arg);
void* ta(void* arg);


int main(int argc, char *argv[])
{
	//check if there is valid number of argument
	if (argc != 3) {
		printf("invalid number of argument/n");
		return -1;

	}

	//The main() function will be passed three parameters via the command line :
	//1. How long to sleep before terminating the whole program(in second).
	//	2. The number of student threads
	int timeToSleep = atoi(argv[1]);
	int numStudent = atoi(argv[2]);
	iniver();
	//printf("\n\nThe value of time to sleep is  : %d\n\n", timeToSleep);
	//printf("The number of consumer is%d\n\n", numStudent);
	//	Perhaps the best option for simulating students programming � as well as the TA providing help to a student � is to have the appropriate threads sleep for a period of time(e.g. 1ms).
	//In addition, please make sure to print meaningful messages at the right stage such as :
	


		//Your main() program should create n student threads and one TA thread, where n is passed in from the command line.
	pthread_t tid;
		int value = 5;
		pthread_create(&tid, NULL, ta, &value);
	
	pthread_t pid[numStudent];
	for (int i = 0; i <= numStudent; i++) {
		int threadNum = i;
		pthread_create(&pid[i], NULL, student, &threadNum);

	}
	
		



	//The main() function will sleep for a period of time and, upon awakening, will terminate the whole program.
	sleep(timeToSleep);

	stop = 1;

/*
	The TA is helping student id.
		Student id goes back to program.
		Student id waits for help in a chair.
		The TA is sleeping.
		The TA is waked up.
		Hint : Refer to the Demo_Conditional_Var code if you decide to use conditional variables.
		*/
	
	
	

	return 0;
}
bool findInQueue(int num) {

	bool waiting = false;
	for (int i = 0; i < 3; i++) {
		sem_wait(&mutex);
		if (num == Chair[i])
			waiting = true;
		sem_post(&mutex);
	}
	return (waiting || num == availableStudent);

}
void insert(int num) {
	Chair[head] = num;
	head = (head + 1) % 3;

}
int remove() {

	int item = Chair[tail];
	Chair[tail] = -1;
	tail = (tail + 1) % 10;
	return item;

}

void iniver() {
	if (sem_init(&full, 0, 3) == -1)
		printf("%s\n", strerror(errno));
	if (sem_init(&empty, 3, 0) == -1)
		printf("%s\n", strerror(errno));
	if (sem_init(&mutex, 0, 1) == -1)
		printf("%s\n", strerror(errno));
	if (sem_init(&mutAvlStd, 0, 1) == -1)
		printf("%s\n", strerror(errno));
	stdAvl = false;
	tabusy = false;
	taSleeping = true;
	fstStd = true;
	head = tail = count=0;

}
void* student(void* arg) {
	int* stdPtr = (int*)arg;
	int studentId = *stdPtr;
	bool programming = false;
	bool gettinghelp = false;
	while (stop == 0) {
		if (!stdAvl && head == tail ) {
			stdAvl = true;
			
			sem_wait(&mutAvlStd);
			availableStudent = studentId;
			sem_post(&mutAvlStd);
			

		}
		else if (tail == (head + 1) % 3 && !programming) {
			printf("Student %d Goback to programming\n\n", studentId);
			programming = true;

		}
		else if (!programming && !gettinghelp){
			sem_wait(&full);
			sem_wait(&mutex);
			
			insert(studentId);
			count++;
			printf("Student %d is sitting in chair (%d students waiting) \n\n", studentId, count);
			sem_post(&empty);
			sem_post(&mutex);

		}
		while (findInQueue(studentId)) {
		};


		//sleep(2);


		//printf("This is Student thread %d \n \n", studentId);
	}
}

//Each student thread will alternate between programming for a period of time and seeking help from the TA.If the TA is available, they will obtain help.
//Otherwise, they will either sit in a chair in the hallway or , if no chairs are available, will resume programming and will seek help at a later time.
//If a student arrives and notices that the TA is sleeping, the student must wake up the TA.When the TA finishes helping a student, the TA must check to
//see if there are students waiting for help in the hall way.If so, the TA must help each of these students in turn.If no students are present, the TA 
//may return to napping.

void* ta(void* arg) {

	while (stop == 0) {
		if (!stdAvl && head == tail) {
			taSleeping = true;
			printf("TA goes back to Sleep \n\n");
			 

		}
		while (stdAvl) {
			
			sem_wait(&mutAvlStd);
			if (taSleeping){
				taSleeping = false;
				printf("Student %d arrives for help\n\n", availableStudent);
				printf("TA is woken up... grumble...\n\n");
			}
			printf("TA is helping student %d \n\n", availableStudent);
			sleep(1);
			sem_wait(&empty);
			sem_wait(&mutex);
			
			
			availableStudent = remove();
			sem_post(&mutAvlStd);
			
			count--;
			sem_post(&full);
			sem_post(&mutex);
		}
	}
}