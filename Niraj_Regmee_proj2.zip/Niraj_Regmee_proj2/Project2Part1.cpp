#include <unistd.h>
#include <sys/types.h>  
#include <errno.h>      
#include <stdio.h>      
#include <stdlib.h>     
#include <string.h>     
#include <semaphore.h>
#include <fstream>
#include <sys/wait.h>

int BoundedBuffer[10];
int head = 0;
int tail = 0;
sem_t full, empty, mutex;
int stop;

void insert(int threadnum);
void* producer(void* arg);
void remove(int threadnum);
void* consumer(void* arg);
void inisem();
int main(int argc, char *argv[])
{
	
	if (argc != 4) {
		printf("invalid number of argument/n");
			return -1;

	}
	int timeToSleep = atoi(argv[1]);
	int numConsumer = atoi(argv[3]);
	int numProducer = atoi(argv[2]);
	inisem();
	for (int i = 0; i < 10; i++) {

		BoundedBuffer[i] = -1;

	}
	
	pthread_t pid[numProducer];
	for (int i = 0; i <= numProducer; i++) {
		int numthread = i;
	pthread_create(&pid[i], NULL, producer, &numthread);
	
	
	}
	pthread_t tid[numConsumer];
	for (int j = 0; j <= numConsumer; j++) {
		int threadNum = j;
	
	pthread_create(&tid[j], NULL, consumer, &threadNum);

	}
	
	
	sleep(timeToSleep);
	
	stop = 1;

	return 0;
}

void* producer(void* arg) {
	int* numberPtr = (int*)arg;
	int number = *numberPtr;
	while (stop == 0){
	sem_wait(&full);
	sem_wait(&mutex);
	insert(number);
	sem_post(&empty);
	sem_post(&mutex);
	}
}
void* consumer(void* arg) {

	int* numberPtr = (int*)arg;
	int number = *numberPtr;
	while (stop == 0) {


		sem_wait(&empty);
		sem_wait(&mutex);
		remove(number);
		sem_post(&full);
		sem_post(&mutex);
	}
	
}
void remove(int threadnum) {

	int item = BoundedBuffer[tail];
	BoundedBuffer[tail] = -1;
	tail = (tail+1) % 10;
	printf("Thread %d consume the value:  %d \n\n",threadnum, item);
	
}
void insert(int threadnum) {
	int item = rand() % 1000;
	BoundedBuffer[head] = item;
	head = (head+1) % 10;
	printf("Thread %d produce the value:  %d \n\n",threadnum, item);
}
void inisem() {
	if (sem_init(&full, 0, 10) == -1)
		printf("%s\n", strerror(errno));
	if (sem_init(&empty, 10, 0) == -1)
		printf("%s\n", strerror(errno));
	if (sem_init(&mutex, 0, 1) == -1)
		printf("%s\n", strerror(errno));
}