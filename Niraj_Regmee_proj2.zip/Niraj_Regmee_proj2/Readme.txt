Part1/ part2
	complile the Project2Part1.cpp 
	link the pthread with-lpthread
	and Destination file.
	.o file for part 1 must be passed with 3 argument
		1st argument is time the main program will be awake
		2nd aggument is for number of producer thread
		3rd Argument is for number of consumer
	.o file for part 2 must be passed with 2 argument
		1st argument is time the main program will be awake
		2nd aggument is for number of student thread.